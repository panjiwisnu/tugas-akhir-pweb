<?php
	include "connect/koneksi.php";
	$kodebuku	= $_GET['kodebuku'];
	$namabuku	= $_GET['namabuku'];
	$harga		= $_GET['harga'];
	$tersedia	= $_GET['tersedia'];
	$jumlah		= $_GET['jumlah'];
	$subtotal	= $_GET['subtotal'];

	if ($_GET['lihat']) {
		header("location:transaksi.php?kodebuku=$kodebuku&namabuku=
			$namabuku&harga=$harga&tersedia=$tersedia");
	}
	if ($_GET['add']) {
		$simpan = mysql_query("INSERT INTO sementara values ('$kodebuku',
			'$namabuku','$harga','$jumlah','$subtotal') ");
		echo "<script type='text/javascript'>
				var retVal = confirm('Tambah Transaksi Lagi ??');
				if( retVal == true){
					document.location.href = 'transaksi.php';
				}
			  	else{
      				alert('Hitung Transaksi!');
	  				document.location.href = 'transaksi_proses.php';
   				}
			</script>";
	}
?>

