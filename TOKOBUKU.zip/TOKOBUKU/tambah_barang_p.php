<?php 
	include "connect/koneksi.php";
	$kodebuku	= $_GET['kodebuku'];
	$namabuku	= $_GET['namabuku'];
	$penulis	= $_GET['penulis'];
	$penerbit	= $_GET['penerbit'];
	$tersedia	= $_GET['tersedia'];
	$harga		= $_GET['harga'];
	
	if (($kodebuku)&&empty($namabuku)&&empty($penulis)&&empty($penerbit)
		&&empty($tersedia)&&empty($harga)&&empty($gambar)) {
		echo "Gagal menyimpan, pastikan semua terisi dengan benar";
		echo "<a href='tambah_barang.php'>Kembali";
	}
	else {
		$tambah = mysql_query("INSERT INTO daftarbuku values('$kodebuku','$namabuku','$penulis',
			'$penerbit','$tersedia','$harga') ");
		echo "<script type='text/javascript'>
				var retVal = confirm('Data tersimpan dan Apa Anda Masih Ingin Menambah Barang ?');

				if( retVal == true){
					alert('Oke Silahkan Tambah Lagi');
					document.location.href = 'tambah_barang.php';
				}
			  	else{
      				alert('Kembali ke daftar barang!');
	  				document.location.href = 'home.php';
   				}
			</script>";
	}
?>