<!DOCTYPE html>
<html>
	<head>
 		<title>Login</title>
 		<link rel="stylesheet" href="style_index.css"/>
	</head>

<body bgcolor="Silver">
	<div class="container">
		<div class="main">
			<h2 align="center">Login Kasir Toko Buku</h2>
			<hr/>	
				 <p><form action="login.php" method="post">
 					<input class="input" type="text" name="username" placeholder="Username">
 					<input class="input" name="password" placeholder="Password"  type="password">
 				 <input class="submit" type="submit" id ="submit" value="Login">
 			</form>
		</div>
	</div>
</body>
</html>