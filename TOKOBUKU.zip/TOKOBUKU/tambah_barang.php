<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="asset/css/bootstrap.css">
	<link rel="stylesheet"  type="text/css">
	<title>Item Buku</title>
	

	
</head>
<body class="container"><h3 align="center">Tambah Buku</h3>
	<div class="wrapper">
	<header>
		<h1></h1>
		<a href="home.php" class="btn btn-info">Kembali</a>
	</header>
	<form action="tambah_barang_p.php" method="get">
		<br><table class="table">
			<tr>
				<td>KODE BUKU</td>
				<td><input type="text" class="form-control" name="kodebuku" ></td>
			</tr>
			<tr>
				<td>NAMA BUKU</td>
				<td><input type="text" class="form-control" name="namabuku" ></td>
			</tr>
			<tr>
				<td>PENULIS</td>
				<td><input type="text" class="form-control" name="penulis"></td>
			</tr>
			<tr>
				<td>PENERBIT</td>
				<td><input type="text" class="form-control" name="penerbit"></td>
			</tr>
			<tr>
				<td>TERSEDIA</td>
				<td><input type="number" class="form-control" name="tersedia"></td>
			</tr>
			<tr>
				<td>HARGA</td>
				<td><input type="number" class="form-control" name="harga"></td>
			</tr>
			<tr>

				<td colspan="2" align="right">
					<input type="submit" class="btn btn-info" value="Tambah">
					<input type="reset" class="btn btn-danger" value="Batal">
				</td>
			</tr>
		</table>
	</form>

</body>
</html>