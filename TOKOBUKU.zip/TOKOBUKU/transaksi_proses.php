<?php include"connect/koneksi.php" ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="asset/css/bootstrap.css">
	<link rel="stylesheet"  type="text/css">
	<style type="text/css">
	head, section, footer, aside, nav, article, figure, figcaption {
		display: block;}
	nav{
		clear: both;
		color: #330000;
		background-color: white;
		height: 15px 15px;
		margin-top: 70px;}
		</style>

	</style>
</head>
<body class="container">
	<div class="wrapper">
	<header>
		<h1></h1>
		<nav>
			<ul>
			<li><a href="home.php" >Home</a></li>
			<li><a href="">Contac Us</a></li>
			</ul>
		</nav>
	</header>
	<div class="panel panel-default">`
		<div class="panel-body" align="center">
			<div style="font-style:arial;">
				<!-- <form action="hitung.php" method="get"> -->
					<table class="table">
						<tr align="right">
						 <td>
						
					</td>
							<td></td>
							<td><input type="text" class="form-control-static" name="id_transaksi" style="border: none; padding: 20px;"></td>
							<td></td>
						</tr>
					</table>
					 <tr>
		        <td>
		       

					<table class="table">
				    	<tr style="color:red;">
				        	<td>Kode Buku</td>
				            <td>Nama Buku</td>
				            <td>Harga</td>
				            <td>Jumlah</td>
				            <td>Sub Total</td>
				        </tr>
						<?php
						$total = 0;
						$kembalian = 0;
						$tampil = mysql_query("SELECT * from sementara");
							while($tr = mysql_fetch_array($tampil)) {
								echo "
									<tr>
										<td>".$tr['kodebuku']."</td>
								        <td>".$tr['namabuku']."</td>
								        <td> Rp. ".$tr['harga']."</td>
								        <td>".$tr['jumlah']."</td>
								        <td> Rp. ".$tr['subtotal']."</td>
								    </tr>
								";
								$total = $total + $tr['subtotal'];
							}
						?>
						<tr><td colspan="5"></td></tr>
						<tr>
							<td>Total</td>
							<td></td>
							<td></td>
							<td></td>
							<td colspan="2"><input type="text" style="border:none;" name="total" id="total" value="<?php echo 'Rp.'.$total ?>" onkeyup="back();"></td>
						</tr>
						<tr>
							<td>Uang Pelanggan</td>
							<td colspan="3"><input type="text" class="form-control" name="dibayar" id="dibayar" onkeyup="back();"></td>
							<td>
								<input type="submit" name="bayar" class="btn btn-primary" value="BAYAR" onclick="back();">
							</td>
						</tr>
						<tr>
							<td>Kembalian</td>
							<td colspan="3"><input type='text' class='form-control' name='kembalian' id='kembalian' style='padding: 15px;' onblur="back();" onfocus="back();"></td>
						</tr>
						<tr>
							<td><a href="transaksi.php ">Balik</a></td>
						</tr>
					</table>
				<!-- </form> -->
			</div>
		</div>
	</div>
	<script>
		function back() {
		    var a1 = document.getElementById('dibayar').value;
		    var a2 = document.getElementById('total').value;
		    var cashback = parseInt(a1) - parseInt(a2);
		    	if (!isNaN(cashback)) {
		         	document.getElementById('kembalian').value = cashback;
		       	}
		}

	</script>

</body>
</html>