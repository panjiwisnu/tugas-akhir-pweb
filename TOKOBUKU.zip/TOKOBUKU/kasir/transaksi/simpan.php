<?php
$host = "localhost";
$username = "root";
$db_name = "kasir";

mysql_connect($host, $username);
mysql_select_db($db_name);

/*$nama = $_POST['nama'];
$email = $_POST['email'];
$kodemobil = $_POST['kode_mobil'];
$harga = $_POST['harga'];
$reservasi = $_POST['reservasi'];
$tanggalkembali = $_POST['tanggalkembali'];
$status = $_POST['status'];
$selisih = ((abs(strtotime($reservasi)-strtotime($tanggalkembali)))/(60*60*24));
$totalbayar = ($harga*$selisih);	
$query = mysql_query("INSERT INTO booking (nama, email, kodemobil, harga, bayar,reservasi, status, tanggalkembali) VALUES ('$nama', '$email', '$kodemobil', $totalbayar, 0,'$reservasi', 'pending', '$tanggalkembali')");*/
if ($query) {
	echo "SUUKSES";
	echo $selisih;
	header("location:tampilinput.php");
}
else {
	echo'GAGAL';
	echo "";
}
?>