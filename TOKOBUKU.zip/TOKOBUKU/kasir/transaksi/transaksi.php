<!DOCTYPE html>
<html>
<head>
	<title>Transaksi</title>
	<style type="text/css">
	head, section, footer, aside, nav, article, figure, figcaption {
		display: block;}
	body {
		color: #666666;
		background-color: #f9f8f6;
		background-image: url("images/buku.jpg");
		background-position: 50px 50px;
		font-family: sans-serif;
		margin: 20px;}
	.wrapper {
		width: 870px;
		margin: 10px auto 10px;
		border: 2px solid #000000;
		background-color: #ffffff;}
	header {
		height: 230px;
		background-image: url(image/buku.jpg);}
	h1 {
		text-indent: -9999px;
		width: 940px;
		height: 130px;
		margin: 0px;}
	nav, footer{
		clear: both;
		color: #330000;
		background-color: #FFFFCC;
		height: 15px 15px;
		margin-top: 70px;}
	nav ul {
		margin: 0px;
		padding: 5px 0px 5px 30px;}
	nav li {
		display: inline;
		margin-right: 40px;}
	nav li a{
		color: #000000;}
	nav li a:hover, nav li a.current{
		color: #ccffff;}
	section.course{
		float: left;
		width: 659px;
		border-right: 1px solid #eeeeee;}
	article{
		clear: both;
		overflow: auto;
		width: 100%;}
	hgroup {
		margin-top: 40px;}
	figure{
		float: left;
		width: 510px;
		height: 310px;
		padding: 5px;
		margin: 20px;
		border: 1px solid #eeeeee;}
	figcaption{
		font-size: 90%;
		text-align: left;}
	aside{
		width: 230px;
		float: left;
		padding: 0px 0px 0px 20px;}
	aside section a {
		display: block;
		padding: 10px;
		border-bottom: 1px solid #eeeeee;}
	aside section a:hover {
		color: #985d6a;
		background-color: #efefef;}
	a {
		color: #de6581;
		text-decoration: none;}
	h1, h2, h3 {
		font-weight: normal;}
	h2 {
		margin: 10px 0px 5px 0px;
		padding: 0px;}
	h3 {
		margin: 0px 0px 10px 0px;
		color: #de6581;}
	
	.btn {
    border: none;
    color: #000000;
    padding: 12px 24px;
    text-align: center;
    display: inline-block;
    font-size: 16px;
    cursor: pointer;
		}
	.alert {background-color: #f9f8f6;} /* Green */
	.alert:hover {background-color: #f9f8f6;}
	</style>

	</style>
</head>
<body>
<div class="wrapper">
	<header>
		<h1></h1>
		<nav>
			<ul>
			<li><a href="home.html">Home</a></li>
			<li><a href="">Contac Us</a></li>
			</ul>
		</nav>
	</header>
	<section class="courses">
	<?php
		include 'connect.php';
		//$query = mysql_query("SELECT * FROM `barang` WHERE kd_buku = '$kd_buku'");
		//while ($data = mysql_fetch_array($query)){
		//	$kd_buku = $_POST["kd_bku"];
		//	$judul_buku = $_POST["name"];
		//	$Penerbit = $_POST["hrg"];
		//	$harga = $_POST["hrga"];
		//	$stok = $_POST["satuan"];
//	}
	?>
		<article>
			<figure>
				<hgoup>
					<form name="" method="POST" action="simpan.php">
						<table border="1">
							<tr>
								<td>Kode Buku</td>
								<td><input type="text" name="kd_buku" ></td>
							</tr>
							<tr>
								<td>Judul Buku</td>
								<td><input type="text" name="judul_buku"></td>
							</tr>
								<tr>
								<td>Harga satun</td> 
								<td><input type="text" name="harga"></td>
							</tr>
							<tr>
								<td>Jumlah Beli</td>
								<td><input type="text" name="jml_beli" ></td>
							</tr>
							</tr>
								<td>Tgl Beli</td>
	          					<td><input type="date" name="kembali"></td>
        					</tr>
							<tr>
								<td>Total</td>
								<td><input type="text" name="total" ></td>
							</tr>
							<tr>
								<td>Bayar Cash</td>
								<td><input type="text" name="cash" td>
							</tr>
								<td>Kembali</td>
	          					<td><input type="text" name="kembali"></td>
        					</tr>
        					
								<td colspan="2" align="center"><input type="submit" value="Simpan"></td>
							</tr>
						</table>
					</form>
			</figure>
		</article>
	</section>
</div>
</body>
</html>