<?php
	$koneksi = mysql_connect("localhost","root","") or die("Koneksi Gagal !" . mysql_error());
	$database = mysql_select_db("kasir");
	
	$kd_buku = $_POST['kd_buku'];
	$judul_buku = $_POST['judul_buku'];
	$harga = $_POST['harga'];
	$jml_beli = $_POST['jml_beli'];
	$tgl_beli = $_POST['tgl_beli'];
	$total = $_POST['total'];
	$cash = $_POST['cash'];
	//$kembalian = $_POST['kembalian'];
	//$kembali=$kembali+$POST['cash']-$POST['total'];
	//$simpan = mysql_query("insert into transaksi values('$kd_buku','$','$hrg','$hrga','$satuan')");
	$simpan = mysql_query("insert into transaksi values ('$judul_buku', '$harga', '$jml_beli','$tgl_beli', 'total', '$cash')");
	//$simpan_a = mysql_query("insert into stok values('$kd','$satuan')");
?>

<script type="text/javascript">
	var retVal = confirm("Data tersimpan dan Apa Anda Masih Ingin Menambah Transaksi ?");
	if( retVal == true){
      alert("Oke Silahkan Tambah Lagi");
	  document.location.href = "tambah_transaksi.html";
	  }
	  else{
      alert("Kembali ke daftar barang!");
	  document.location.href = "tampiltransaksi.php";
   }
</script>