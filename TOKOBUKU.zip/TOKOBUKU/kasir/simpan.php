<?php
$host = "localhost";
$username = "root";
$db_name = "kasir";

mysql_connect($host, $username);
mysql_select_db($db_name);

$nama = $_POST['kd_buku'];
$judul_buku = $_POST['judul_buku'];
$harga = $_POST['harga'];
$jml_beli = $_POST['jml_beli'];
$tgl_beli = $_POST['tgl_beli'];
$total = $_POST['total'];
$cash = $_POST['cash'];             
$kembalian = $cash - $total;
//$totalbayar = ($harga*$selisih);
$query = mysql_query("INSERT INTO transaksi (kd_buku, judul_buku, harga, jml_beli, tgl_beli, total, cash, kembalian) VALUES ('$nama', '$judul_buku', '$harga', '$jml_beli','$tgl_beli', 'total', '$cash', '$kembalian')");
if ($query) {
	echo "SUUKSES";
	echo $selisih;
	header("location: tampilinput.php");
}
else {
	echo'GAGAL';
	echo "";
}
?>