<?php
	$koneksi = mysql_connect("localhost","root","") or die("Koneksi Gagal !" . mysql_error());
	$database = mysql_select_db("kasir");
	?>
<!DOCTYPE html>
<html>
<head>
	<title>Transaksi</title>
	<style type="text/css">
	head, section, footer, aside, nav, article, figure, figcaption {
		display: block;}
	body {
		color: #666666;
		background-color: #f9f8f6;
		background-image: url("image/cs.jpg");
		background-position: 50px 50px;
		font-family: sans-serif;
		margin: 20px;}
	.wrapper {
		width: 870px;
		margin: 10px auto 10px;
		border: 2px solid #000000;
		background-color: #ffffff;}
	header {
		height: 230px;
		background-image: url(image/mobil.png);}
	h1 {
		text-indent: -9999px;
		width: 940px;
		height: 130px;
		margin: 0px;}
	nav, footer{
		clear: both;
		color: #330000;
		background-color: #FFFFCC;
		height: 15px 15px;
		margin-top: 70px;}
	nav ul {
		margin: 0px;
		padding: 5px 0px 5px 30px;}
	nav li {
		display: inline;
		margin-right: 40px;}
	nav li a{
		color: #000000;}
	nav li a:hover, nav li a.current{
		color: #ccffff;}
	section.course{
		float: left;
		width: 659px;
		border-right: 1px solid #eeeeee;}
	article{
		clear: both;
		overflow: auto;
		width: 100%;}
	hgroup {
		margin-top: 40px;}
	figure{
		float: left;
		width: 610px;
		height: 310px;
		padding: 5px;
		margin: 20px;
		border: 1px solid #eeeeee;}
	figcaption{
		font-size: 90%;
		text-align: left;}
	aside{
		width: 230px;
		float: left;
		padding: 0px 0px 0px 20px;}
	aside section a {
		display: block;
		padding: 10px;
		border-bottom: 1px solid #eeeeee;}
	aside section a:hover {
		color: #985d6a;
		background-color: #efefef;}
	a {
		color: #de6581;
		text-decoration: none;}
	h1, h2, h3 {
		font-weight: normal;}
	h2 {
		margin: 10px 0px 5px 0px;
		padding: 0px;}
	h3 {
		margin: 0px 0px 10px 0px;
		color: #000000;}
	.btn {
    border: none;
    color: #000000;
    padding: 12px 24px;
    text-align: center;
    display: inline-block;
    font-size: 16px;
    cursor: pointer;
					}
	.alert {background-color: #f9f8f6;} /* Green */
	.alert:hover {background-color: #f9f8f6;}
	

	</style>
</head>
<body>
<div class="wrapper">
	<header>
	<h1></h1>
		<nav>
			<ul>
			<li><a href="home.php">Home</a></li>
			
			<li><a href="">Contac Us</a></li>
			</ul>
		</nav>
	</header>
	<section class="courses">
		<article>
			<figure>
			<table border="1">
	<tr>
		<th>Kode Buku</th>
		<th>Judul Buku</th>
		<th>Harga satun</th>
		<th>Jumlah Beli</th>
		<th>Tgl Beli</th>
		<th>Total</th>
		<th>Bayar Cash</th>
		<th>Kembali </th>
		<th>AKSI</th>
	</tr>
	<?php
		include 'connect.php';
		$query = mysql_query("SELECT * FROM transaksi WHERE kd_buku ='$kd_buku'");
		while ($data=mysql_fetch_array($query)) {
			$kd_buku = $data['kd_buku'];
			$id = $data['kd_buku'];
	?>
	<tr>
		<td><?php echo $data['kd_buku'];?></td>
		<td><?php echo $data['judul_buku'];?></td>
		<td><?php echo $data['harga'];?></td>
		<td><?php echo $data['jml_beli'];?></td>
		<td><?php echo $data['tgl_beli'];?></td>
		<td><?php echo $data['total'];?></td>
		<td><?php echo $data['cash'];?></td>
		<td><?php echo $data['kembalian'];?></td>
		<th><a href="home.php?kd_buku=<?php echo $kd_buku;?>&id=<?php echo $id;?>"><button>cetak</button></a></th>
	</tr>
	<?php }?>
</table>
			</figure>
		</article>
	</section>
</div>
</body>
</html>