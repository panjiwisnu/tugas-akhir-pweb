    <?php
	$koneksi = mysql_connect("localhost","root","") or die("Koneksi Gagal !" . mysql_error());
	$database = mysql_select_db("kasir");
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Update Barang</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    </head>

    <body class="container">
        <h1 align="center">Update Barang</h1>
        <form action="proses_update.php" method="post" enctype="multipart/form-data">
            <table class="table">
                <tr>
                   	<td>No Buku</td>
                    <td>Judul Buku</td>
                    <td>Penerbit Buku</td>
                    <td>Harga</td> 
                    <td>Jumlah</td>
                    <td>Images</td>          
                </tr>
                <tr>
                    <?php
                        $kd_buku = $_POST['kd'];
                        $lihat_1 = mysql_query("select * from barang where barang.kd_buku = '$kd_buku'");
                        $arr_lihat1 = mysql_fetch_array($lihat_1);
                    ?>
                    <td>
                        <input type="text" value="<?php echo $arr_lihat1['kd_buku']; ?>" disabled="disabled" /><input type="hidden" name="kd_buku" value="<?php echo $arr_lihat1['kd_buku']; ?>" />
                    </td>
                    <td>
                        <input type="text" class="form-control" name="judul_buku" value="<?php echo $arr_lihat1['judul_buku']; ?>" />
                    </td>
                    <td>
                        <input type="text" class="form-control" name="Penerbit" value="<?php echo $arr_lihat1['Penerbit']; ?>"  />
                    </td>
                    <td>
                        <input type="number" class="form-control" name="harga" value="<?php echo $arr_lihat1['harga']; ?>" />
                    </td>
                     <td>
                        <input type="number" class="form-control" name="stok" value="<?php echo $arr_lihat1['stok']; ?>" />
                    </td>
                     <td>
                        <input type="text" class="form-control" name="gambar" value="<?php echo $arr_lihat1['gambar']; ?>" />
                    </td>
                    <td>
                        <input type="submit" class="btn btn-primary" value="Update" />
                    </td>
                </tr>
                <tr>
                    <td colspan="5" align="left"><a href="index.php">&lt;&lt; Back TO INDEX</a></td>
                </tr>
            </table>
        </form>
    </body>
</html>