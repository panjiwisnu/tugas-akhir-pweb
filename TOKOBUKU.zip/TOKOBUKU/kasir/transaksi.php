<?php 
	include "connect/koneksi.php";
	include "bs/bs.php"; 
?>
<!DOCTYPE html>
<html>
<head>
	<title>TRANSAKSI</title>
	<link rel="stylesheet" type="text/css" href="asset/css/bootstrap.css">
</head>
<body class="container">
	<h1 align="center">TRANSAKSI</h1>

	<form action="transaksi_p.php" method="get" enctype="multipart/form-data">
		<table class="table">
			<tr>
				<td>Pilih Kode</td>
				<td>
					<select name="kd_buku" id="kd_buku" class="btn btn-default">	
						<?php
							$lihat = mysql_query("select * from barang");
							while($data = mysql_fetch_array($lihat))
							{
								echo "<option id='kd_buku' value=".$data['kd_buku'].">".$data['kd_buku']."</option>";
							}
						?>
					</select>
				<input type="submit" value="LIHAT" class="btn btn-default" name="lihat"></td>
			</tr>
			<?php
				if (isset($_GET['kd_buku'])) {
					$kd_buku	= $_GET['kd_buku'];
					$judul_buku	= $_GET['judul_buku'];
					$harga		= $_GET['harga'];
					$stok	= $_GET['stok'];
				} else {
					$kd_buku	= "";
					$judul_buku	= "";
					$harga 		= "";
					$stok	= "";
				}
				$lihatt = mysql_query("select kd_buku, judul_buku, harga, stok from Barang where kd_buku = '$kd_buku'");
			        while($tampil = mysql_fetch_array($lihatt)) {
					echo "<tr>
						<td>Kode Buku</td>
						<td>
							<input type='text' class='form-control' value=".$tampil['kd_buku']." name='kd_buku' id='kd_buku' style='padding: 15px;'>
						</td>
					</tr>
					<tr>
						<td>Nama Buku</td>
						<td>
							<input type='text'  class='form-control' value=".$tampil['judul_buku']." name='judul_buku' id='judul_buku' style='padding: 15px;'>
						</td>
					</tr>
					<tr>
						<td>Harga</td>
						<td>
							<input type='text' class='form-control' value=".$tampil['harga']." name='harga' id='harga' onkeyup='sum();' style='padding: 15px;'>
						</td>
					</tr>
					<tr>
						<td>Tersedia</td>
						<td>
							<input type='text' class='form-control' value=".$tampil['stok']." name='stok' id='stok' style='padding: 15px;'>
						</td>
					</tr>
					<tr>
						<td>Jumlah Beli</td>
						<td>
							<input type='text' class='form-control' name='jumlah' id='jumlah' onkeyup='sum();' style='padding: 15px;'>
						</td>
					</tr>
					<tr>
						<td>Sub Total</td>
						<td>
							<input type='text' class='form-control' name='subtotal' id='subtotal' style='padding: 15px;'>
						</td>
					</tr>";
				} ?>
			<tr>
				<td colspan="2">
				<a href="home.php" class="btn btn-primary">HOME</a>
					<input type="submit" name="add" value="TAMBAH" class="btn btn-primary">
					<a href="transaksi_proses.php" class="btn btn-primary">LIHAT</a>
				</td>
			</tr>
		</table>
	</form>

	<script>
		function sum() {
		      var txtFirstNumberValue = document.getElementById('jumlah').value;
		      var txtSecondNumberValue = document.getElementById('harga').value;
		      var result = parseInt(txtFirstNumberValue) * parseInt(txtSecondNumberValue);
		      if (!isNaN(result)) {
		         document.getElementById('subtotal').value = result;
		      }
		}

	</script>



</body>
</html>
