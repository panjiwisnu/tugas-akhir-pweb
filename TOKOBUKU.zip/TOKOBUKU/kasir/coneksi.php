<?php
$host = "localhost";
$username = "root";
$db_name = "kasir";

mysql_connect($host, $username);
mysql_select_db($db_name);

?>