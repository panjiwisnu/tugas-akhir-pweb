<?php
	$koneksi = mysql_connect("localhost","root","") or die("Koneksi Gagal !" . mysql_error());
	$database = mysql_select_db("kasir");
?>
<form action="hitung.php" method="post">
	<table>
		<tr>
			<td>Kode Buku</td>
			<td>Jumlah Beli</td>
		</tr>
		<?php
			$jumlah =$_POST['jlh_beli'];

			for ($a=1; $a < $jumlah; $a++) { 
				$b[$a] = $_POST['id_pembeli'];
			}

			for ($i=0; $i < $jumlah; $i++) { 
				echo "
					<tr>
						<td>
							<select name='kd".$i."'>";
							$lihat = mysql_query("SELECT * from barang");
							while ($data = mysql_fetch_array($lihat)) {
								echo "
									<option value=".$data['kd_brg'].">".$data['kd_brg']."</option>
								";
							}
				echo "
							</select>
						</td>
						<td>
							<input type='number' name='satuan".$i."' id='satuan' />
							<input type='hidden' name='jlh_angka' value='".$jumlah."' />
							<input type='hidden' name='id_pembeli".$i."' value='$b[$i]' />
						</td>
					</tr>
				";
			}
		?>
		<tr>
			<td>Total Harga</td>
			<td><input type="number" name="total_beli"></td>
		</tr>
		<tr>
			<td>Bayar</td>
			<td><input type="number" name="bayar"></td>
		</tr>
		<tr>
			<td>kembalian</td>
			<td><input type="number" name="kembalian"></td>
		</tr>
		<tr>
			<td><input type="submit" value="JUMLAH"></td>
		</tr>
	</table>
</form>