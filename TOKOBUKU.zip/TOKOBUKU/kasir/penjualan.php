<!DOCTYPE html>
<html>
<head>
	<title>Penjualan</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body>
	<h1 align="center">PENJUALAN BUKU</h1>
	<form action="jlh_jual.php" method="post">
		<table class="table">
			<tr>
				<td>Jumlah Beli</td>
				<td><input type="number" class="form-control" name="jlh_beli"></td>
			</tr>
			<tr>
				<td>Identitas Pembeli</td>
				<td><input type="text" class="form-control" name="id_pembeli"></td>
			</tr>
			<tr>
				<td><input type="submit" class="btn btn-primary" value="LANJUT"></td>
			</tr>
		</table>
	</form>
</body>
</html>