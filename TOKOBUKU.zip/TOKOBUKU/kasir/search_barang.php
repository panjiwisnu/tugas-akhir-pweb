<?php
	$koneksi = mysql_connect("localhost","root","") or die("Koneksi Gagal !" . mysql_error());
	$database = mysql_select_db("kasir");
	
	$barang = $_POST['brg'];
	
?>
<!DOCTYPE html>
<html>
<head>
<title>Search Barang</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>

<body class="container">
<h1 align="center">Hasil Searching</h1>
<div>
	<div>
    	<div>
        	<div>
            <table class="table">
            <tr>
                <th>No.</th>
                <th>No Buku</th>
                <th>Judul Buku</th>
                <th>Penerbit Buku</th>
                <th>Satuan</th>
            </tr>
            <?php
            $no = 1;
            $lihat = mysql_query("select *,Penerbit as 'Penerbit' from barang where kd_buku = '$barang' or judul_buku like '%$barang%' or Penerbit = '$barang'");
            while($hasil = mysql_fetch_array($lihat))
            {
                echo "<tr>
                        <td>".$no."</td>
                        <td>".$hasil['kd_buku']."</td>
                        <td>".$hasil['judul_buku']."</td>
                        <td>".$hasil['Penerbit']."</td>
                        <td>".$hasil['stok']."</td>
                      </tr>
                ";
                $no ++;
            }
            ?>
            <tr>
            	<td colspan="5" align="left"><a href="home.php">&lt;&lt; Back TO HOME</a></td>
            </tr>
	        </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
