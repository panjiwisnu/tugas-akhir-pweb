-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 21 Mar 2017 pada 15.58
-- Versi Server: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kasir`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `kd_buku` varchar(10) NOT NULL,
  `judul_buku` varchar(100) DEFAULT NULL,
  `Penerbit` varchar(50) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`kd_buku`, `judul_buku`, `Penerbit`, `stok`) VALUES
('BRG001', 'Hidup Berawal Dari Mimpi', 'Kurniesa Publishing', 31),
('BRG002', 'Berani Teriak Berani Bertindak', 'PT. Buana Ilmu Populer', 45),
('BRG003', 'Hidup Bebas Belenggu Utang', 'Gospel Press', 40),
('BRG004', 'Sang Pemimpi', 'Bentang Pustaka', 65),
('BRG005', 'Pendidikan Rusak-rusakan', 'LKiS Yogyakarta', 54);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembeli`
--

CREATE TABLE IF NOT EXISTS `pembeli` (
  `id_pembeli` varchar(10) DEFAULT NULL,
  `kd_brg` varchar(10) DEFAULT NULL,
  `jlh_beli` int(11) DEFAULT NULL,
  `tgl_beli` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `stok`
--

CREATE TABLE IF NOT EXISTS `stok` (
  `kd_buku` varchar(10) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `stok`
--

INSERT INTO `stok` (`kd_buku`, `stok`) VALUES
('BRG001', 35),
('BRG002', 63),
('BRG003', 50),
('BRG004', 65),
('BRG005', 54),
('BRG006', 12),
('BRG007', 18),
('BRG008', 58),
('BRG009', 74),
('BRG010', 74),
('BRG011', 22),
('BRG012', 27),
('BRG013', 47),
('BRG014', 17),
('BRG015', 57),
('BRG016', 50),
('BRG006', 5),
('BRG001', 31);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kd_buku`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
