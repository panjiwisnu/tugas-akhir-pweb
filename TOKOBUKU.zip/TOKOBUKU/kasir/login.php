<?php
include 'connect.php';

$username = $_POST['username'];
$password = $_POST['password'];

$query    = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
$runquery = $connect->query($query);

if($runquery->num_rows > 0){
 session_start();
 $_SESSION['username'] = $username;
 ?>Anda berhasil login. silahkan menuju <a href="home.php">Halaman HOME</a><?php
} else {
 echo '<h3>
Username atau Kata Sandi Salah!</h1><a href="index.php">Login Ulang</a>
';
}

?>
