 <?php
	$koneksi = mysql_connect("localhost","root","") or die("Koneksi Gagal !" . mysql_error());
	$database = mysql_select_db("kasir");
	
	$kd = $_POST['kd'];
	$nama = $_POST['nama'];
	$hrg = $_POST['hrg'];
	$hrga = $_POST['hrga'];
	$satuan = $_POST['satuan'];
	$gambar = $_POST['gambar'];

	$simpan = mysql_query("insert into barang values('$kd','$nama','$hrg','$hrga','$satuan','$gambar')");
	$simpan_a = mysql_query("insert into stok values('$kd','$satuan')");
?>

<script type="text/javascript">
	var retVal = confirm("Data tersimpan dan Apa Anda Masih Ingin Menambah Barang ?");
	if( retVal == true){
      alert("Oke Silahkan Tambah Lagi");
	  document.location.href = "tambah_barang.html";
	  }
	  else{
      alert("Kembali ke daftar barang!");
	  document.location.href = "home.php";
   }
</script>