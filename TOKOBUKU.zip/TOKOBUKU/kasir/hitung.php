<?
	$koneksi = mysql_connect("localhost","root","") or die("Koneksi Gagal !" . mysql_error());
	$database = mysql_select_db("kasir");

	$jumlah = $_POST['jlh_angka'];
	for ($i=1; $i <=$jumlah ; $i++) { 
		$id_pembeli[$i] = $_POST['id_pembeli'.$i];
		$kd_brg[$i] = $_POST['kd'];
		$satuan_brg[$i] = $_POST['satuan'.$i];

		mysql_query("insert into pembeli values('".$id[$i]."','".$kd_brg[$i]."','".$satuan_brg[$i]."','".$tgl[$i]."')");
		mysql_query("update barang set stok = stok - '".$satuan_brg[$i]."' where kd_brg = '".$kd_brg[$i]."'");
	}

	echo "";
?>