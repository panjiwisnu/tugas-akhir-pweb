<?php

$koneksi = mysql_connect("localhost","root","") or die("Koneksi Gagal !" . mysql_error());
	$database = mysql_select_db("kasir");
	
	$kd_buku = $_POST['kd_buku'];
	$judul_buku = $_POST['judul_buku'];
	$Penerbit = $_POST['Penerbit'];
	$harga = $_POST['harga'];
	$stok = $_POST['stok'];
	$gambar = $_POST['gambar'];
	
	$simpan = mysql_query(" Update barang set judul_buku = '$judul_buku', Penerbit = '$Penerbit',  harga = '$harga', stok = '$stok' , gambar = '$gambar' where kd_buku = '$kd_buku'");
	//$simpan_a = mysql_query(" Update stok set stok = '$stok' where kd_buku = '$kd_buku'");

?>

<script type="text/javascript">
	document.location.href = "home.php";
</script>