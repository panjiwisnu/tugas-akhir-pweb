<?php

session_start();
if(!isset($_SESSION['username'])) {
 header("Location: home.php?access_denied");
}
$koneksi = mysql_connect("localhost","root","") or die("Koneksi Gagal !" . mysql_error());
	$database = mysql_select_db("kasir");
?>

<!DOCTYPE html>

<html>
<body>
 
	<head>
		<link rel="stylesheet"  type="text/css">
		<!-- <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> -->
	<title>Kasir Buku</title>
	<style type="text/css">
	head, section, footer, aside, nav, article, figure, figcaption {
		display: block;}
	body {
		color: #666666;
		background-color: #f9f8f6;
		background-image: url("image/cs.jpg");
		background-position: 50px 50px;
		font-family: sans-serif;
		margin: 20px;}
 	.wrapper {
		width: 870px;
		margin: 10px auto 10px;
		border: 2px solid #000000;
		
		background-color: #FFFFCC;}
	.transparan1{background:#000;opacity:0.4;filter:alpha(opacity=40);}
	header {
		height: 230px;
		background-image: url("image/as.jpg");}
	h1 {
		text-indent: -9999px;
		width: 940px;
		height: 130px;
		margin: 0px;}
	nav, footer{
		clear: both;
		color: #330000;
		background-color: #FFFFCC;
		height: 15px 15px;
		margin-top: 70px;}
	nav ul {
		margin: 0px;
		padding: 5px 0px 5px 30px;}
	nav li {
		display: inline;
		margin-right: 40px;}
	nav li a{
		color: #000000;}
	nav li a:hover, nav li a.current{
		color: #ccffff;}
	section.course{
		float: left;
		width: 659px;
		border-right: 1px solid #eeeeee;}
	article{
		clear: both;
		overflow: auto;
		width: 100%;}
	hgroup {
		margin-top: 40px;}
	
	
	
	aside section a {
		display: block;
		padding: 10px;
		border-bottom: 1px solid #eeeeee;}
	aside section a:hover {
		color: #985d6a;
		background-color: #efefef;}
	a {
		color: #de6581;
		text-decoration: none;}
	h1, h2, h3 {
		font-weight: normal;}
	h2 {
		margin: 10px 0px 5px 0px;
		padding: 0px;}
	h3 {
		margin: 0px 0px 10px 0px;
		color: #de6581;}
			}
	.alert {background-color: #f9f8f6;} /* Green */
	.alert:hover {background-color: #f9f8f6;}
	</style>

	</style>
</head>

<body>

<div class="wrapper">
	<header>
		<h1></h1>
		<nav>
			<ul>
			<li><a href="home.php" >Home</a></li>
			<li><a href="tambah_barang.html">Tambah Buku</a></li>
			<li><a href="item.php">Cek Item</a></li>
			<li><a href="tambah_transaksi.html">Transaksi Penjualan</a></li>
			<li><a href="logout.php">Keluar</a></li>
			</ul>
		</nav>
	</header>



		
		

	<br><center>DATA TRANSAKSI</center></br>

		<div class="panel panel-default">
			<div class="panel-body" align="center">
		        <div style="width:700px; float:center">
		            <table class="table" border="3" bgcolor="white">
					<div class="form-group">
			        </div>
			    </form>
	</center><hr>

				<tr style='background-color:white'><td><b>No.</b></td>

					<td><b>No Buku</b></td>
					<td><b>Judul Buku</b></td>
					<td><b>Harga Satuan</b></td>
					<td><b>Jumlah Beli</b></td>
					<td><b>Tgl Beli</b></td>
					<td><b>Total</b></td>
					<td><b>Bayar Cash</b></td>
					<td><b>Kembalian</b></td>
				</tr>
		       

		            <?php
							$dataPerPage = 7 ; //Jumlah Page Yang inign ditampilkan di halaman depan
							if(isset($_GET['page']))
							{
								$noPage = $_GET['page'];
							}
							else $noPage = 1;
							
							$offset = ($noPage - 1) * $dataPerPage;
							
		            $no = 1;
		            $lihat = mysql_query("select *, judul_buku as 'judul_buku' from transaksi LIMIT $offset, $dataPerPage");
		            while($hasil = mysql_fetch_array($lihat))
		            {
		                echo "<tr>
		                        <td>".$no."</td>
		                        <td>".$hasil['kd_buku']."</td>
		                        <td>".$hasil['judul_buku']."</td>
		                        <td>".$hasil['harga']."</td>
		                        <td>".$hasil['jml_beli']."</td>
		                        <td>".$hasil['tgl_beli']."</td>
		                        <td>".$hasil['total']."</td>
		                        <td>".$hasil['cash']."</td>
		                        <td>".$hasil['kembalian']."</td>
		                        

								


		                      </tr>
		                ";
		                $no ++;
		            }
		            ?>
			        </table>

			        <?php
		            		$query = "SELECT COUNT(*) AS jumData FROM transaksi";
							$hasil = mysql_query($query);
							$data = mysql_fetch_array($hasil);
							$jumData = $data['jumData'];
							$jumPage = ceil($jumData/$dataPerPage);
							if ($noPage > 1) echo  "<a id='page' href='".$_SERVER['PHP_SELF']."?page=".($noPage-1)."'>&lt;&lt;</a>";
							for($page = 1; $page <= $jumPage; $page++)
							{
								if ((($page >= $noPage - 3) && ($page <= $noPage + 3)) || ($page == 1) || ($page == $jumPage))
								 {
									if (($page != ($jumPage - 1)) && ($page == $jumPage))
									{
										echo "...";
									}
									if ($page == $noPage)
									{
									echo " <b>".$page."</b> ";
									}
									else 
									{
									echo " <a id='page' href='".$_SERVER['PHP_SELF']."?page=".$page."'>".$page."</a> ";
									}
									
									$page = $page;
								}
							}
							if ($noPage < $jumPage) echo "<a id='page' href='".$_SERVER['PHP_SELF']."?page=".($noPage+1)."'>&gt;&gt;</a>";
						?>
		            </div>
		    </div>
		</div>
</body>
	        
		            

	<center>
		<p><form method="post" action="logout.php" enctype="multipart/form-data" class="navbar-form navbar-left" role="logout">
		     
			 </div>
		</form>
	</center>

</html>


			        	
