 <?php
	$koneksi = mysql_connect("localhost","root","") or die("Koneksi Gagal !" . mysql_error());
	$database = mysql_select_db("kasir");
?>
<!DOCTYPE html>
<html>
<body bgcolor="Silver">
 

	<head>
		<link rel="stylesheet" type="text/css" >
		<!-- <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> -->
	<title>Kasir Buku</title>

	<script type="text/javascript">
		function update(){
			document.location.hre = "index.php";
		}
	</script>

	</head>

	<body class="container">

		<h1 align="center">SISTEM APLIKASI KASIR</h1>
<center>
		
		
<p>
				<td style="padding:35px;"></td>
					<form method="post" action="search_barang.php" enctype="multipart/form-data" class="navbar-form navbar-left" role="search">
		        		<div class="form-group">
			        		<input type="text" class="form-control" name="brg" />
			        		<input type="submit" class="btn btn-primary" value="Search Barang" />
			        	</div>
			        </form>
				

    			</li>
			</ul>
		</nav>
</center>



	<center>
		<table class="tabel">
		    <tr>
		        <td>
			        <form action="delete.php" method="post" enctype="multipart/form-data">
						<select name="kd" class="btn btn-warning">
			            <?php
							$lihat = mysql_query("select * from Barang");
							while($data = mysql_fetch_array($lihat))
							{
								echo "<option ' id='kd' value=".$data['kd_buku'].">".$data['kd_buku']."</option>";
							}
						?>
			        	</select><input type="submit" value="Delete Barang" class="btn btn-info" />
			        </form>
		        </td>
		        <td style="padding:35px;"></td>
		        <td>
			        <form action="update.php" method="post" enctype="multipart/form-data">
						<select name="kd" class="btn btn-warning">
			            <?php
							$lihat = mysql_query("select * from Barang");
							while($data = mysql_fetch_array($lihat))
							{
								echo "<option onclick='isi()' id='kd' value=".$data['kd_buku'].">".$data['kd_buku']."</option>";
							}
						?>
			        	</select><input type="submit" value="Update Barang" class="btn btn-info" />


			        </form>
		        </td>
		    </tr>
		</table>
	</center><hr>


		<div class="panel panel-default">
			<div class="panel-body" align="center">
		        	<div style="width:700px; float:center">
		            <table class="table" border="2" bgcolor="white">

<p>
<form method="post" action="tambah_barang.html" enctype="multipart/form-data" class="navbar-form navbar-left" role="tambah">
		        		<div class="form-group">
			        		<input type="submit" class="btn btn-primary" value="Tambah Barang" />
			        	</div>
		      <p>      
		            <tr>
		                <th>No.</th>
		                <th>No Buku</th>
		                <th>Judul Buku</th>
		                <th>Penerbit Buku</th>
		                <th>Stok</th>
		            </tr>
		            

		            <?php
							$dataPerPage = 6; //Jumlah Page Yang inign ditampilkan di halaman depan
							if(isset($_GET['page']))
							{
								$noPage = $_GET['page'];
							}
							else $noPage = 1;
							
							$offset = ($noPage - 1) * $dataPerPage;
							
		            $no = 1;
		            $lihat = mysql_query("select *, penerbit as 'penerbit' from barang LIMIT $offset, $dataPerPage");
		            while($hasil = mysql_fetch_array($lihat))
		            {
		                echo "<tr>
		                        <td>".$no."</td>
		                        <td>".$hasil['kd_buku']."</td>
		                        <td>".$hasil['judul_buku']."</td>
		                        <td>".$hasil['penerbit']."</td>
		                        <td>".$hasil['stok']."</td>
		                      </tr>
		                ";
		                $no ++;
		            }
		            ?>
			        </table>

			        
		            <?php
		            		$query = "SELECT COUNT(*) AS jumData FROM barang";
							$hasil = mysql_query($query);
							$data = mysql_fetch_array($hasil);
							$jumData = $data['jumData'];
							$jumPage = ceil($jumData/$dataPerPage);
							if ($noPage > 1) echo  "<a id='page' href='".$_SERVER['PHP_SELF']."?page=".($noPage-1)."'>&lt;&lt;</a>";
							for($page = 1; $page <= $jumPage; $page++)
							{
								if ((($page >= $noPage - 3) && ($page <= $noPage + 3)) || ($page == 1) || ($page == $jumPage))
								 {
									if (($page != ($jumPage - 1)) && ($page == $jumPage))
									{
										echo "...";
									}
									if ($page == $noPage)
									{
									echo " <b>".$page."</b> ";
									}
									else 
									{
									echo " <a id='page' href='".$_SERVER['PHP_SELF']."?page=".$page."'>".$page."</a> ";
									}
									
									$page = $page;
								}
							}
							if ($noPage < $jumPage) echo "<a id='page' href='".$_SERVER['PHP_SELF']."?page=".($noPage+1)."'>&gt;&gt;</a>";

						?>
		            </div>
		    </div>
		</div>
		</body>
	</html>
