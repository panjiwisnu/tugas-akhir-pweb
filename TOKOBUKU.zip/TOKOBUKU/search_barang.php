<?php
	$koneksi = mysql_connect("localhost","root","") or die("Koneksi Gagal !" . mysql_error());
	$database = mysql_select_db("kasirbuku");
	
	$barang = $_POST['brg'];
	
?>
<!DOCTYPE html>
<html>
<head>
<title>Search Barang</title>
<link rel="stylesheet" type="text/css" href="asset/css/bootstrap.css">
</head>

<body class="container">
<h1 align="center">Hasil Searching</h1>
<div>
	<div>
    	<div>
        	<div>
            <table class="table">
            <tr>
                <th>No.</th>
                <th>Kode Buku</th>
                <th>Judul Buku</th>
                <th>Penulis</th>
                <th>Penerbit Buku</th>
                <th>Tersedia</th>
                <th>Satuan</th>
                <td><b>Images</b></td>
            </tr>
            <?php
            $no = 1;
            $lihat = mysql_query("select *,kodebuku as 'kodebuku' from daftarbuku where kodebuku = '$barang' or kodebuku like '%$barang%' or namabuku like '%$barang%' or penerbit = '$barang'");
            while($hasil = mysql_fetch_array($lihat))
            {
                echo "<tr>
                        <td>".$no."</td>
                        <td>".$hasil['kodebuku']."</td>
                        <td>".$hasil['namabuku']."</td>
                        <td>".$hasil['penulis']."</td>
                        <td>".$hasil['penerbit']."</td>
                        <td>".$hasil['tersedia']."</td>
                        <td> Rp. ".$hasil['harga']."</td>
                      </tr>
                ";
                $no ++;
            }
            ?>
            <tr>
            	<td colspan="5" align="left"><a href="home.php">&lt;&lt; Back TO HOME</a></td>
            </tr>
	        </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
