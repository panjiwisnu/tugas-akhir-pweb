<?php

	include "connect/koneksi.php";
	
	$kode = $_POST['kd'];
	
	$hapus = mysql_query("DELETE FROM daftarbuku WHERE kodebuku = '".$kode."'");

?>

<script type="text/javascript">
	alert("Buku Terhapus");
	document.location.href = "home.php";
</script>