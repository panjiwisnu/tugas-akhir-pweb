<?php

	include "connect/koneksi.php";
	
	$kodebuku = $_POST['kodebuku'];
	$namabuku = $_POST['namabuku'];
	$penulis = $_POST['penulis'];
	$penerbit = $_POST['penerbit'];
	$tersedia = $_POST['tersedia'];
	$harga = $_POST['harga'];
	
	$simpan = mysql_query("UPDATE daftarbuku SET namabuku = '$namabuku', penulis = '$penulis', penerbit = '$penerbit', 
		tersedia = '$tersedia', harga = '$harga' WHERE kodebuku = '$kodebuku'");

?>

<script type="text/javascript">
	document.location.href = "home.php";
</script>